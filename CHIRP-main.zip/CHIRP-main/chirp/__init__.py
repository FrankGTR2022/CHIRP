"""CHIRP Initializer."""
