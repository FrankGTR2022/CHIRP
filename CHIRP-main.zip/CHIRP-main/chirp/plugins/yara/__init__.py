"""Yara plugin initializer."""

from . import run

entrypoint = run.run
